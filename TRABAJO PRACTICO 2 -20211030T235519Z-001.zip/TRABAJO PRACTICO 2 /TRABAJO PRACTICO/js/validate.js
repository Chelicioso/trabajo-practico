function validateForm() {
    if (document.forms["contactForm"]["fname"].value == "") {
        document.getElementById("vName").innerHTML = "El nombre no puede estar vacio";
    }else{
        document.getElementById("vName").innerHTML ="";
    }

    if (document.forms["contactForm"]["lname"].value == "") {
        document.getElementById("vLastname").innerHTML = "El Apellido no puede estar vacio";
    }else{
        document.getElementById("vLastname").innerHTML ="";
    }

    if (document.forms["contactForm"]["email"].value == "") {
        document.getElementById("vEmail").innerHTML = "El Email no puede estar vacio";
    }else{
        document.getElementById("vEmail").innerHTML ="";
    }

    if (document.forms["contactForm"]["birthday"].value == "") {
        document.getElementById("vBirthday").innerHTML = "La fecha no puede estar vacia";
    }else{
        document.getElementById("vBirthday").innerHTML ="";
    }
  }